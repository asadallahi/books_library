@extends('master')

@section('content')
    {!! form($form) !!}
@endsection