<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" crossorigin="anonymous">

    <title>Twyla Books Reivew</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Twyla Books</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(url('books')); ?>">Books <span class="sr-only">(current)</span></a>
            </li>


        </ul>

        <ul class="navbar-nav float-right">
            <li class="nav-item active">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    Welcome, <?php echo e($_COOKIE['username']); ?>

                </a>
                <div class="dropdown-menu dropdown-menu-right " aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a>
                </div>
            </li>


        </ul>


    </div>
</nav>
<div class="container mt-4">
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    <?php endif; ?>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
<!-- Content here -->
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
</body>
</html>