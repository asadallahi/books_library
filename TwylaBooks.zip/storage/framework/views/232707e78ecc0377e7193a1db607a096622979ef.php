<?php $__env->startSection('content'); ?>
    <a class="btn btn-success" href="<?php echo e(url('books/create')); ?>"><i class="fa fa-plus-circle"></i> Add new Book</a>
    <?php if(!count($books)): ?>
        <div class="alert alert-danger text-center mt-4" role="alert">
            There is no Books!
        </div>

    <?php else: ?>
        <div class="row mt-4">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 mb-2">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fa fa-book"></i> <?php echo e($book->title); ?></h5>
                            <p class="card-text">ISBN: <?php echo e($book->isbn); ?></p>
                            <div class="float-left">
                                <a href="<?php echo e(url('books').'/'.$book->id); ?>" class="btn btn-primary">Reviews</a>
                            </div>
                            <div class="float-right"><i class="fa fa-user"></i> By <strong><?php echo e($book->user->username); ?></strong></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>