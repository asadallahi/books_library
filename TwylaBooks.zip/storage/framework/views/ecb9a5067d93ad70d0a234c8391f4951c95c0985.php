<?php $__env->startSection('content'); ?>
    <div class="card mt-4">
        <div class="card-body">
            <h4 class="card-title float-left"><i class="fa fa-book"></i> <?php echo e($book->title); ?></h4>
            <div class="float-right"><i class="fa fa-user-circle"></i> By <strong><?php echo e($book->user->username); ?></strong></div>
            <div class="clearfix"></div>
            <p class="card-text">ISBN: <?php echo e($book->isbn); ?></p>
            <div class="">
                <?php if(count($book_reviews)): ?>
                    <h5><i class="fa fa-comment"></i> Previous Reviews</h5>
                    <?php $__currentLoopData = $book_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-2">
                            <div class="card-body">
                                <div class="card-subtitle">
                                    <div class="float-left"><i class="fa fa-user"></i> By: <?php echo e($book_review->user->username); ?></div>
                                    <div class="float-right"> Rating: <?php echo e($book_review->rating); ?></div>
                                    <div class="clearfix"></div>

                                </div>
                                <?php echo e($book_review->review); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card bg-secondary">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fa fa-plus-circle"></i> Add Review</h5>
                        <?php echo form($form); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>